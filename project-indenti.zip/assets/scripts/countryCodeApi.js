const obj = JSON.parse(countryCodeJson);

console.log(obj)